def zamiana(x):
    j = len(x) - 1
    i = 0
    while j > i:
        if x[j] < 0 <= x[i]:
            x[i], x[j] = x[j], x[i]
            i += 1
            j -= 1
        elif x[i] > 0 and x[j] > 0:
            j -= 1
        elif x[i] < 0 and x[j] < 0:
            i += 1
        else:
            i += 1
            j -= 1
    return x


zbior = [5, -2, -3, 1, 0, -4, 3]
print(zamiana(zbior))
